var mongoose = require("mongoose");

var healthSchema = new mongoose.Schema({
    username: String,
    count: Number,
    age: Number,
    weight: Number,
    height: Number,
    bmi: Number,
    sleepPatterns: Number,
    cholesterol: Number,
    bloodSugar: Number,
    bloodPressure: Number,
    timeStamp: Number,
    dateAndTime: String,
    prevHash: String,
    currentHash: String,
    count: Number
});

module.exports = mongoose.model("HealthParameter",healthSchema);
