var mongoose = require("mongoose");

var UserDataSchema = new mongoose.Schema({
    username: String,
    timestamp: Number,
    no_of_blocks: Number
});


module.exports = mongoose.model("UserData",UserDataSchema);
